//Lab-11: Lab exercise on handling CSV and JSON files
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONObject;

public class CSVOperation_11 {

    public static void main(String[] args) {
        String csvFile = "C:/Users/Admin/Downloads/tvmarketing.csv";
        String line;
        String cvsSplitBy = ",";

        // List to store data
        List<JSONObject> dataList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // Skip the header row
            br.readLine();

            // Read the CSV file line by line
            while ((line = br.readLine()) != null) {
                // Split the line by comma
                String[] data = line.split(cvsSplitBy);
                // Create JSON object for each row
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("TV", data[0]);
                jsonObject.put("Sales", Double.parseDouble(data[1]));
                jsonObject.put("Profit/Loss", calculateProfitOrLoss(Double.parseDouble(data[1])));
                // Add the JSON object to the list
                dataList.add(jsonObject);
            }

            // Print the CSV data as JSON objects
            System.out.println("CSV Data as JSON:");
            for (JSONObject jsonObject : dataList) {
                System.out.println(jsonObject.toJSONString());
            }

            // Perform basic operations
            double totalSales = 0;
            for (JSONObject jsonObject : dataList) {
                totalSales += (double) jsonObject.get("Sales");
            }
            System.out.println("Total Sales: " + totalSales);
            double averageSales = totalSales / dataList.size();
            System.out.println("Average Sales: " + averageSales);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to calculate profit or loss
    public static String calculateProfitOrLoss(double sales) {
        // Define a condition for profit or loss, you can customize it based on your requirement
        if (sales > 10) {
            return "Profit";
        } else {
            return "Loss";
        }
    }
}
