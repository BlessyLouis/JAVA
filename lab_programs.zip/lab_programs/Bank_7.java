// LAB-07:Implement multithreading – Thread class, Runnable interface, synchronization and thread communication.

// importing libraries for usage of list 
import java.util.ArrayList;
import java.util.List;
// importing libraries for taking input from user
import java.util.Scanner;
// creation of main class Bank_7 
public class Bank_7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the number of customers
        System.out.print("Enter the number of loan applications: ");
        int numberOfApplications = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        List<LoanApplication> loanApplications = new ArrayList<>();
        // Get details of loan applications
        for (int i = 0; i < numberOfApplications; i++) {
            System.out.println("Enter details for loan application " + (i + 1) + ":");
            System.out.print("Customer ID: ");
            String customerId = scanner.nextLine();
            System.out.print("Loan Amount (Rs.): ");
            double loanAmount = scanner.nextDouble();
            System.out.print("Loan Duration (months): ");
            int loanDuration = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            loanApplications.add(new LoanApplication(customerId, loanAmount, loanDuration));
        }


        System.out.println("Loan application processing started...");

        for (LoanApplication loanApplication : loanApplications) {
            Thread thread = new Thread(loanApplication);
            thread.start(); // Start a new thread for each loan application
        }

        // Wait for all threads to complete
        try {
            Thread.sleep(3000); // Wait for 3 seconds for demonstration purposes
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("All loan applications processed.");
    }
}


class LoanApplication implements Runnable {
    private static final Object lock = new Object(); // Lock for synchronization
    private static int applicationCount = 0; // Shared resource: number of loan applications processed
    private String customerId;
    private double loanAmount;
    private int loanDuration;

    public LoanApplication(String customerId, double loanAmount, int loanDuration) {
        this.customerId = customerId;
        this.loanAmount = loanAmount;
        this.loanDuration = loanDuration;
    }

    @Override
    public void run() {
        try {
            // Simulate processing time
            Thread.sleep((long) (Math.random() * 2000));

            // Synchronize access to shared resource (applicationCount)
            synchronized (lock) {
                applicationCount++;
                System.out.println("Loan application processed for Customer ID: " + customerId + ", Loan Amount: $" + loanAmount + ", Loan Duration: " + loanDuration + " months. Application count: " + applicationCount);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

