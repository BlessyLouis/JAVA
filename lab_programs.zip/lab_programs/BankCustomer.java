//importing pacakage "Scanner" for input operation
import java.util.Scanner;
//Creation of main class
public class BankCustomer {
    // Public data members
    public String customerName;
    public int customerAge;
    public String customerAddress;

    // Private data  member
    private double accountBalance;

    // Public method to deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            accountBalance += amount;
            System.out.println(amount + " deposited successfully.");
        } else {
            System.out.println("Invalid amount to deposit.");
        }
    }

    // Public method to display account details
    public void displayAccountDetails() {
        System.out.println("Customer Name: " + customerName);
        System.out.println("Customer Age: " + customerAge);
        System.out.println("Customer Address: " + customerAddress);
        System.out.println("Account Balance: " + accountBalance);
    }

    // Private method for withdrawal
    private void withdrawal(double amount) {
        if (amount > 0 && amount <= accountBalance) {
            accountBalance -= amount;
            System.out.println(amount + " withdrawn successfully.");
        } else {
            System.out.println("Insufficient balance or invalid amount to withdraw.");
        }
    }

    // Main method of the BankCustomer class
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankCustomer customer1 = new BankCustomer();

        // Taking input from the user
        System.out.print("Enter customer name: ");
        customer1.customerName = scanner.nextLine();

        System.out.print("Enter customer age: ");
        customer1.customerAge = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter customer address: ");
        customer1.customerAddress = scanner.nextLine();

        // Display initial account details
        System.out.println("\nInitial Account Details:");
        customer1.displayAccountDetails();

        // Depositing money
        System.out.print("\nEnter amount to deposit: ");
        double amountToDeposit = scanner.nextDouble();
        customer1.deposit(amountToDeposit);

        // Display updated account details
        System.out.println("\nAccount Details after deposit:");
        customer1.displayAccountDetails();

        // Withdrawing money
        System.out.print("\nEnter amount to withdraw: ");
        double amountToWithdraw = scanner.nextDouble();
        customer1.withdrawal(amountToWithdraw);

        // Display updated account details
        System.out.println("\nAccount Details after withdrawal:");
        customer1.displayAccountDetails();


    }
}
