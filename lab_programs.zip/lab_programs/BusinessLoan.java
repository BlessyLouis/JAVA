
package banking.loans;
// BusinessLoan class implementing Loan interface
public class BusinessLoan implements Loaninterface {
    private double loanAmount;
    private double remainingAmount;

    public BusinessLoan(double loanAmount) {
        this.loanAmount = loanAmount;
        this.remainingAmount = loanAmount;
    }


    public void applyForLoan(double amount) {
        remainingAmount += amount;
        System.out.println("Business loan applied. Remaining amount: " + remainingAmount);
    }

    public void repayLoan(double amount) {
        if (amount <= remainingAmount) {
            remainingAmount -= amount;
            System.out.println("Loan repayment successful. Remaining amount: " + remainingAmount);
        } else {
            System.out.println("Cannot repay more than the remaining amount.");
        }
    }
}
