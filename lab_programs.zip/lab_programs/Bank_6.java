//importing the Scanner class from the util package for input operation

import java.util.Scanner;

//creation of main class Bank_6

public class Bank_6{

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
// input credit score
        System.out.print("Enter your credit score: ");
        double creditScore = scanner.nextDouble();
// creating object object for BankLoan
        BankLoan bankLoan = new BankLoan();

        try {
            bankLoan.approveLoan(creditScore);
            System.out.println("Congratulations! Your loan has been approved.");
        } catch (CreditScoreBelowThresholdException e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Sorry, your loan cannot be approved at this time.");
        }

    }
}
//CreditScoreBelowThresholdException class representing an exception that occurs when a customer's credit score is below a certain threshold

class CreditScoreBelowThresholdException extends Exception {
    public CreditScoreBelowThresholdException(String message) {
        super(message);
    }
}

class BankLoan {
    private double creditScoreThreshold = 700;

    public void approveLoan(double creditScore) throws CreditScoreBelowThresholdException {
        if (creditScore < creditScoreThreshold) {
            throw new CreditScoreBelowThresholdException("Loan cannot be approved. Credit score below threshold.");
        }
        System.out.println("Loan approved successfully!");
    }
}

