//LAB-08: Implementation of Generics Concepts

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Bank_8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a mutual fund
        System.out.print("Enter the name of the mutual fund: ");
        String fundName = scanner.nextLine();
        MutualFund<Object> mutualFund = new MutualFund<>(fundName);

        // Add assets to the mutual fund
        System.out.println("Enter assets for the mutual fund (press Enter to stop):");
        while (true) {
            System.out.print("Enter asset type (Stock/Bond): ");
            String assetType = scanner.nextLine().trim();
            if (assetType.isEmpty()) {
                break;
            }
            if (assetType.equalsIgnoreCase("Stock")) {
                System.out.print("Enter stock symbol: ");
                String symbol = scanner.nextLine();
                System.out.print("Enter stock price: ");
                double price = scanner.nextDouble();
                scanner.nextLine(); // Consume newline character
                mutualFund.addAsset(new Stock(symbol, price));
            } else if (assetType.equalsIgnoreCase("Bond")) {
                System.out.print("Enter bond name: ");
                String name = scanner.nextLine();
                System.out.print("Enter bond yield: ");
                double yield = scanner.nextDouble();
                scanner.nextLine(); // Consume newline character
                mutualFund.addAsset(new Bond(name, yield));
            } else {
                System.out.println("Invalid asset type. Please enter 'Stock' or 'Bond'.");
            }
        }



        // Display assets of the mutual fund
        mutualFund.displayAssets();
    }
}


class MutualFund<T> {
    private String fundName;
    private List<T> assets;

    public MutualFund(String fundName) {
        this.fundName = fundName;
        this.assets = new ArrayList<>();
    }

    public void addAsset(T asset) {
        assets.add(asset);
    }

    public void displayAssets() {
        System.out.println("Assets of " + fundName + ":");
        for (T asset : assets) {
            System.out.println(asset);
        }
    }
}

class Stock {
    private String symbol;
    private double price;

    public Stock(String symbol, double price) {
        this.symbol = symbol;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Stock Symbol: " + symbol + ", Price: $" + price;
    }
}

class Bond {
    private String name;
    private double yield;

    public Bond(String name, double yield) {
        this.name = name;
        this.yield = yield;
    }

    @Override
    public String toString() {
        return "Bond Name: " + name + ", Yield: " + yield + "%";
    }
}

