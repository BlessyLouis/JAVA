import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class DataVisualization_12 {

    public static void main(String[] args) {
        // Load data from CSV file
        double[][] data = loadDataFromCSV("C:/Users/Admin/Downloads/advertising.csv");

        // Extract data
        double[] tvData = data[0];
        double[] radioData = data[1];
        double[] newspaperData = data[2];
        double[] salesData = data[3];

        // Create the bar chart
        JFreeChart barChart = createBarChart(tvData, radioData, newspaperData);
        displayChart("Bar Chart", barChart);

        // Create the line chart
        JFreeChart lineChart = createLineChart(salesData);
        displayChart("Line Chart", lineChart);

        // Create the pie chart
        JFreeChart pieChart = createPieChart(salesData);
        displayChart("Pie Chart", pieChart);
    }

  // Load data from CSV file, extracting only the first 100 rows
private static double[][] loadDataFromCSV(String csvFile) {
    double[][] data = null;
    try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
        String line;
        int rowCount = 0;
        boolean skipHeader = true; // Flag to skip the header row
        while ((line = br.readLine()) != null && rowCount < 100) {
            if (skipHeader) {
                skipHeader = false; // Skip the header row
                continue;
            }
            String[] values = line.split(",");
            if (data == null) {
                // Initialize the data array based on the number of columns
                data = new double[values.length][100]; // Fixed size for 100 rows
            }
            for (int i = 0; i < values.length; i++) {
                data[i][rowCount] = Double.parseDouble(values[i]);
            }
            rowCount++;
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return data;
}
    // Create a bar chart
    private static JFreeChart createBarChart(double[] tvData, double[] radioData, double[] newspaperData) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int i = 0; i < tvData.length; i++) {
            dataset.addValue(tvData[i], "TV", "Category " + (i + 1));
            dataset.addValue(radioData[i], "Radio", "Category " + (i + 1));
            dataset.addValue(newspaperData[i], "Newspaper", "Category " + (i + 1));
        }
        return ChartFactory.createBarChart("Advertising Expenditure", "Category", "Spending", dataset);
    }

    // Create a line chart
    private static JFreeChart createLineChart(double[] salesData) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int i = 0; i < salesData.length; i++) {
            dataset.addValue(salesData[i], "Sales", "Month " + (i + 1));
        }
        return ChartFactory.createLineChart("Sales Over Time", "Month", "Sales", dataset);
    }

    // Create a pie chart
    private static JFreeChart createPieChart(double[] salesData) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (int i = 0; i < salesData.length; i++) {
            dataset.setValue("Month " + (i + 1), salesData[i]);
        }
        return ChartFactory.createPieChart("Sales Distribution", dataset);
    }

    // Display a chart in a JFrame
    private static void displayChart(String title, JFreeChart chart) {
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ChartPanel chartPanel = new ChartPanel(chart);
        frame.getContentPane().add(chartPanel, BorderLayout.CENTER);
        frame.setSize(800, 600);
        frame.setVisible(true);
    }
}
