//Lab-03:Implement the static keyword – static variable, static block, static function and static class
//code:

//importing Scanner package for input operation
import java.util.Scanner;

public class BankAccount {
    private static int totalAccounts;
    private static double totalBalance;
    private static int totalTransactions;
    private static double totalDeposits;
    private static double totalWithdrawals;

    static {
        // Initialize static variables
        totalAccounts = 0;
        totalBalance = 0;
        totalTransactions = 0;
        totalDeposits = 0;
        totalWithdrawals = 0;
    }

    private String accountNumber;
    private String accountHolderName;
    private double balance;

    // Constructor
    public BankAccount(String accountNumber, String accountHolderName, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = balance;
        totalAccounts++;
        totalBalance += balance;
    }

    // Method to deposit money into the account
    public void deposit(double amount) {
        balance += amount;
        totalBalance += amount;
        totalTransactions++;
        totalDeposits += amount;
        System.out.println("Deposit Successful, Balance is: Rs." + totalBalance);
    }

    // Method to withdraw money from the account
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            totalBalance -= amount;
            totalTransactions++;
            totalWithdrawals += amount;
            System.out.println("Withdraw Successful, Balance is: Rs." + totalBalance);
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    // Method to display account details
    public void displayAccountDetails() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder Name: " + accountHolderName);
        System.out.println("Balance: Rs." + balance);
    }

    // Static nested class for bank statistics
    public static class BankStatistics {
        // Static method to display bank statistics
        public static void displayBankStatistics() {
            System.out.println("Bank Statistics:");
            System.out.println("Total accounts: " + totalAccounts);
            System.out.println("Total balance: Rs." + totalBalance);
        }

        // Static method to display transaction statistics
        public static void showTransactionStatistics() {
            System.out.println("Transaction Statistics:");
            System.out.println("Total transactions: " + totalTransactions);
            System.out.println("Mean of amount deposited: Rs." + (totalDeposits / totalTransactions));
            System.out.println("Mean of amount withdrawn: Rs." + (totalWithdrawals / totalTransactions));
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Creating a new bank account...");
        System.out.println("Enter account number:");
        String accountNumber = scanner.nextLine();

        System.out.println("Enter account holder name:");
        String accountHolderName = scanner.nextLine();

        System.out.println("Enter initial balance:");
        double initialBalance = scanner.nextDouble();

        BankAccount account = new BankAccount(accountNumber, accountHolderName, initialBalance);

        System.out.println("Account created successfully.");

        // Display total accounts and total balance
        BankStatistics.displayBankStatistics();

        // Perform transactions
        System.out.println("Performing transactions...");
        System.out.println("Enter amount to deposit:");
        double depositAmount = scanner.nextDouble();
        account.deposit(depositAmount);

        System.out.println("Enter amount to withdraw:");
        double withdrawAmount = scanner.nextDouble();
        account.withdraw(withdrawAmount);

        System.out.println("Updated account details:");
        account.displayAccountDetails();

        // Display transaction statistics using the static nested class
        BankStatistics.showTransactionStatistics();

    }
}

