import java.util.*;

public class University_10 {
    public static void main(String[] args) {
        University university = new University();
        Scanner scanner = new Scanner(System.in);

        // Add professors
        System.out.println("Enter professor details (ID, Name, Department):");
        String professorId = scanner.next();
        String professorName = scanner.next();
        String professorDepartment = scanner.next();
        Professor professor = new Professor(professorId, professorName, professorDepartment);
        university.addProfessor(professor);

        // Add students
        System.out.println("Enter student details (ID, Name, Year):");
        String studentId = scanner.next();
        String studentName = scanner.next();
        int studentYear = scanner.nextInt();
        Student student = new Student(studentId, studentName, studentYear);
        university.addStudent(student);

        // Add courses
        System.out.println("Enter course details (Code, Title):");
        String courseCode = scanner.next();
        String courseTitle = scanner.next();
        Course course = new Course(courseCode, courseTitle, professor);
        university.addCourse(course);

        // Enroll student in a course
        System.out.println("Enter student ID to enroll in a course:");
        String enrollStudentId = scanner.next();
        System.out.println("Enter course code:");
        String enrollCourseCode = scanner.next();
        university.enrollStudentInCourse(enrollStudentId, enrollCourseCode);

        // Display courses, professors, and students
        university.displayCourses();
        university.displayProfessors();
        university.displayStudents();

        // Remove a course
        System.out.println("Enter the course code to remove:");
        String removeCourseCode = scanner.next();
        university.removeCourse(removeCourseCode);
        System.out.println("Course removed.");

        // Update professor department
        System.out.println("Enter professor ID to update department:");
        String updateProfessorId = scanner.next();
        System.out.println("Enter new department:");
        String newDepartment = scanner.next();
        university.updateProfessorDepartment(updateProfessorId, newDepartment);
        System.out.println("Professor department updated.");

        // Retrieve student information
        System.out.println("Enter student ID to retrieve information:");
        String retrieveStudentId = scanner.next();
        Student retrievedStudent = university.retrieveStudent(retrieveStudentId);
        if (retrievedStudent != null) {
            System.out.println("Student ID: " + retrievedStudent.getId());
            System.out.println("Student Name: " + retrievedStudent.getName());
            System.out.println("Student Year: " + retrievedStudent.getYear());
        } else {
            System.out.println("Student not found.");
        }

        scanner.close();
    }
}

class Professor {
    private String id;
    private String name;
    private String department;

    public Professor(String id, String name, String department) {
        this.id = id;
        this.name = name;
        this.department = department;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}

class Student {
    private String id;
    private String name;
    private int year;

    public Student(String id, String name, int year) {
        this.id = id;
        this.name = name;
        this.year = year;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}

class Course {
    private String code;
    private String title;
    private Professor professor;
    private List<Student> students;

    public Course(String code, String title, Professor professor) {
        this.code = code;
        this.title = title;
        this.professor = professor;
        this.students = new ArrayList<>();
    }

    // Getters and setters
    public String getCode() {
        return code;
    }

    public String getTitle() {
        return title;
    }

    public Professor getProfessor() {
        return professor;
    }

    public List<Student> getStudents() {
        return students;
    }

    // Method to enroll a student in the course
    public void enrollStudent(Student student) {
        students.add(student);
    }
}

class University {
    private Map<String, Course> courses;
    private Map<String, Professor> professors;
    private Map<String, Student> students;

    public University() {
        courses = new HashMap<>();
        professors = new HashMap<>();
        students = new HashMap<>();
    }

    // Method to add a course to the university
    public void addCourse(Course course) {
        courses.put(course.getCode(), course);
    }

    // Method to remove a course from the university
    public void removeCourse(String courseCode) {
        courses.remove(courseCode);
    }

    // Method to add a professor to the university
    public void addProfessor(Professor professor) {
        professors.put(professor.getId(), professor);
    }

    // Method to update department of a professor
    public void updateProfessorDepartment(String professorId, String newDepartment) {
        Professor professor = professors.get(professorId);
        if (professor != null) {
            professor.setDepartment(newDepartment);
        }
    }

    // Method to add a student to the university
    public void addStudent(Student student) {
        students.put(student.getId(), student);
    }

    // Method to retrieve student information
    public Student retrieveStudent(String studentId) {
        return students.get(studentId);
    }

    // Method to enroll a student in a course
    public void enrollStudentInCourse(String studentId, String courseCode) {
        Course course = courses.get(courseCode);
        if (course != null) {
            Student student = students.get(studentId);
            if (student != null) {
                course.enrollStudent(student);
                System.out.println("Student " + student.getName() + " enrolled in course " + course.getTitle());
            } else {
                System.out.println("Student with ID " + studentId + " not found.");
            }
        } else {
            System.out.println("Course with code " + courseCode + " not found.");
        }
    }

    // Method to display all courses in the university
    public void displayCourses() {
        System.out.println("Courses offered in the university:");
        for (Course course : courses.values()) {
            System.out.println("Code: " + course.getCode() + ", Title: " + course.getTitle() +
                    ", Professor: " + course.getProfessor().getName() + ", Students Enrolled: " + course.getStudents().size());
        }
    }

    // Method to display all professors in the university
    public void displayProfessors() {
        System.out.println("Professors in the university:");
        for (Professor professor : professors.values()) {
            System.out.println("ID: " + professor.getId() + ", Name: " + professor.getName() +
                    ", Department: " + professor.getDepartment());
        }
    }

    // Method to display all students in the university
    public void displayStudents() {
        System.out.println("Students in the university:");
        for (Student student : students.values()) {
            System.out.println("ID: " + student.getId() + ", Name: " + student.getName() +
                    ", Year: " + student.getYear());
        }
    }
}
