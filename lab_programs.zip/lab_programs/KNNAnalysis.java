import java.io.IOException;
import java.text.DecimalFormat;
import weka.classifiers.Classifier;
import weka.core.Instances;
import weka.classifiers.lazy.IBk;
import weka.classifiers.Evaluation;
import weka.core.Instance;
import weka.core.converters.ArffLoader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Import for visualization
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.JFrame;


public class KNNAnalysis {
    public static void main(String[] args) {
        // Import dataset from CSV file
        List<FoodQualityAssessment> dataset = importData("Data_train.csv");

        // Convert target values to numerical labels
        Map<String, Integer> targetLabels = new HashMap<>();
        targetLabels.put("FACILITY CHANGED", 0);
        targetLabels.put("FAIL", 1);
        targetLabels.put("FURTHER INSPECTION REQUIRED", 2);
        targetLabels.put("INSPECTION OVERRULED", 3);
        targetLabels.put("PASS", 4);
        targetLabels.put("PASS(CONDITIONAL)", 5);
        targetLabels.put("SHUT-DOWN", 6);

        // Convert RiskLevel to numerical values
        Map<String, Integer> riskLevelMapping = new HashMap<>();
        riskLevelMapping.put("LOW", 0);
        riskLevelMapping.put("MEDIUM", 1);
        riskLevelMapping.put("HIGH", 2);

        // Convert dataset to ARFF format
        Instances data = convertToArff(dataset, riskLevelMapping);

        try {
            // Train KNN model
            Classifier knn = new IBk();
            knn.buildClassifier(data);

            // Evaluate the model
            Evaluation eval = new Evaluation(data);
            eval.crossValidateModel(knn, data, 10, new Random(1));

            // Display evaluation results
            System.out.println(eval.toSummaryString("\nResults\n======\n", false));

            // Visualize distribution of inspection results
            visualizeInspectionResults(dataset);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to import data from CSV file
    public static List<FoodQualityAssessment> importData(String filename) {
        List<FoodQualityAssessment> dataset = new ArrayList<>();
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            // Skip header line
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                // Assuming the CSV columns are in the same order as the class fields
                FoodQualityAssessment row = new FoodQualityAssessment(parts[0], parts[1], parts[2], parts[3], parts[4],
                        parts[5], parts[6], parts[7], parts[8], parts[9], parts[10], parts[11], parts[12], parts[13],
                        parts[14]);
                dataset.add(row);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dataset;
    }

    // Method to convert dataset to ARFF format
    public static Instances convertToArff(List<FoodQualityAssessment> dataset, Map<String, Integer> riskLevelMapping) {
        // Define attributes
        FastVector atts = new FastVector();
        atts.addElement(new Attribute("ID"));
        // Add other attributes here

        // Create Instances object
        Instances data = new Instances("FoodQualityAssessment", atts, 0);

        // Add data
        for (FoodQualityAssessment entry : dataset) {
            Instance inst = new DenseInstance(data.numAttributes());
            inst.setValue(data.attribute("ID"), Double.parseDouble(entry.ID));
            // Set other attribute values here

            // Add instance to data
            data.add(inst);
        }

        // Set class index
        data.setClassIndex(data.numAttributes() - 1);

        return data;
    }

    // Method to visualize distribution of inspection results
    public static void visualizeInspectionResults(List<FoodQualityAssessment> dataset) {
        // Count occurrences of each inspection result
        Map<String, Integer> resultCounts = new HashMap<>();
        for (FoodQualityAssessment entry : dataset) {
            String result = entry.Inspection_Results;
            resultCounts.put(result, resultCounts.getOrDefault(result, 0) + 1);
        }

        // Create dataset for visualization
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (String result : resultCounts.keySet()) {
            dataset.addValue(resultCounts.get(result), "Inspection Results", result);
        }

        // Create bar chart
        JFreeChart barChart = ChartFactory.createBarChart("Distribution of Inspection Results", "Result", "Count",
                dataset);

        // Display chart in a frame
        JFrame frame = new JFrame("Bar Chart");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new ChartPanel(barChart));
        frame.pack();
        frame.setVisible(true);
    }
}

class FoodQualityAssessment {
    String ID;
    String Date;
    String LicenseNo;
    String FacilityID;
    String FacilityName;
    String Type;
    String Street;
    String City;
    String State;
    String LocationID;
    String Reason;
    String SectionViolations;
    String RiskLevel;
    String Geo_Loc;
    String Inspection_Results;

    public FoodQualityAssessment(String ID, String Date, String LicenseNo, String FacilityID, String FacilityName,
            String Type, String Street, String City, String State, String LocationID, String Reason,
            String SectionViolations, String RiskLevel, String Geo_Loc, String Inspection_Results) {
        this.ID = ID;
        this.Date = Date;
        this.LicenseNo = LicenseNo;
        this.FacilityID = FacilityID;
        this.FacilityName = FacilityName;
        this.Type = Type;
        this.Street = Street;
        this.City = City;
        this.State = State;
        this.LocationID = LocationID;
        this.Reason = Reason;
        this.SectionViolations = SectionViolations;
        this.RiskLevel = RiskLevel;
        this.Geo_Loc = Geo_Loc;
        this.Inspection_Results = Inspection_Results;
    }
}

