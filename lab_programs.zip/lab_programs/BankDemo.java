import java.util.Scanner;
public class BankingDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input from user
        System.out.println("Enter savings account details:");
        System.out.print("Account Number: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Initial Balance: ");
        double balance = scanner.nextDouble();
        System.out.print("Interest Rate (%): ");
        double interestRate = scanner.nextDouble();

        // Creating a savings account object
        SavingsAccount savingsAccount = new SavingsAccount(accountNumber, balance, interestRate);

        // Displaying account info
        System.out.println("\nAccount Details:");
        System.out.println(savingsAccount);

        // Performing transactions
        System.out.print("\nEnter amount to deposit: ");
        double depositAmount = scanner.nextDouble();
        savingsAccount.deposit(depositAmount);

        System.out.print("\nEnter amount to withdraw: ");
        double withdrawAmount = scanner.nextDouble();
        savingsAccount.withdraw(withdrawAmount);

        // Adding interest
        savingsAccount.addInterest();

        // Displaying updated account info
        System.out.println("\nUpdated Account Details:");
        System.out.println(savingsAccount);

        scanner.close();
    }
}


// Class representing a Bank Account
class BankAccount {
    private String accountNumber;
    private double balance;

    // Default constructor
    public BankAccount() {
        this.accountNumber = "Unknown";
        this.balance = 0.0;
    }

    // Constructor overloading
    public BankAccount(String accountNumber) {
        this.accountNumber = accountNumber;
        this.balance = 0.0;
    }

    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Encapsulation: Getter and Setter methods
    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    // Method overloading
    public void deposit(double amount) {
        deposit(amount, "USD");
    }

    public void deposit(double amount, String currency) {
        balance += amount;
        System.out.println("Deposited: " + currency + " " + amount);
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawal of $" + amount + " successful. Remaining balance: $" + balance);
        } else {
            System.out.println("Insufficient funds. Withdrawal failed.");
        }
    }

    // Method overriding
    @Override
    public String toString() {
        return "Account Number: " + accountNumber + ", Balance: $" + balance;
    }
}

// Subclass representing a Savings Account
class SavingsAccount extends BankAccount {
    private double interestRate;

    // Constructor
    public SavingsAccount(String accountNumber, double balance, double interestRate) {
        super(accountNumber, balance);
        this.interestRate = interestRate;
    }

    // Method overriding
    @Override
    public void withdraw(double amount) {
        System.out.println("Withdrawal not allowed for Savings Account");
    }

    // Method overloading
    public void addInterest() {
        double interest = getBalance() * (interestRate / 100);
        deposit(interest);
        System.out.println("Interest of $" + interest + " added to the account.");
    }
}

