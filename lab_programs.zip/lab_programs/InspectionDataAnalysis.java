import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.distance.ManhattanDistance;
import weka.classifiers.lazy.KStar;

public class InspectionDataAnalysis {

    public static void main(String[] args) throws Exception {
        // Replace "path/to/your/data.csv" with the actual path to your data file
        String dataPath = "C:/Users/Admin/Downloads/Data_Train.csv";

        // Load data using Apache Commons CSV
        List<InspectionRecord> records = loadData(dataPath);

        // Perform EDA
        performEDA(records);

        // Feature engineering: Create target variable
        addTargetVariable(records);

        // Convert data to Weka Instances format
        Instances wekaData = convertToWekaInstances(records);

        // Split data into training and testing sets
        int numInstances = wekaData.numInstances();
        int trainSize = (int) Math.round(numInstances * 0.8);  // 80% for training
        Instances trainData = new Instances(wekaData, 0, trainSize);
        Instances testData = new Instances(wekaData, trainSize, numInstances - trainSize);

        // Define attributes for kNN classification
        Attribute inspectionResultsAttr = new Attribute("Inspection_Results", Nominal.make("0:FACILITY CHANGED,1:FAIL,2:FURTHER INSPECTION REQUIRED,3:INSPECTION OVERRULED,4:PASS,5:PASS(CONDITIONAL),6:SHUT-DOWN"));
        Attribute sectionViolationsAttr = new Attribute("SectionViolations");

        // Create the dataset
        ArrayList<Attribute> attList = new ArrayList<Attribute>(2);
        attList.add(inspectionResultsAttr);
        attList.add(sectionViolationsAttr);
        Instances trainInstances = new Instances("InspectionData", attList, trainSize);

        // Populate training data
        for (int i = 0; i < trainSize; i++) {
            Instance inst = new DenseInstance(2);
            inst.setValue((Attribute) attList.get(0), trainData.instance(i).value(inspectionResultsAttr));
            inst.setValue((Attribute) attList.get(1), trainData.instance(i).value(sectionViolationsAttr));
            trainInstances.add(inst);
        }

        // Create and train kNN classifier
        KStar knn = new KStar(1, new ManhattanDistance());  // k = 1, Manhattan distance
        knn.buildClassifier(trainInstances);

        // Perform classification on testing data
        List<String> predictedResults = classifyTestData(knn, testData);

        // Calculate model metrics (accuracy, precision, recall, F1-score)
        evaluateModel(predictedResults, testData);

        // Data visualization (using a library like Plotly or JFreeChart)
        // ... (code for data visualization)

        System.out.println("Data analysis and kNN classification completed successfully.");
    }


    // Load data from CSV file using Apache Commons CSV
    private static List<InspectionRecord> loadData(String dataPath) throws FileNotFoundException {
        List<InspectionRecord> records = new ArrayList<>();
        try (CSVParser parser = CSVParser.parse(new File(dataPath), CSVFormat.DEFAULT)) {
            for (CSVRecord record : parser) {
                InspectionRecord inspectionRecord = new InspectionRecord(
                        record.get("ID"),
                        record.get("Date"),
                        record.get("LicenseNo"),
                        record.get("FacilityID"),
                        record.get("FacilityName"),
                        record.get("Type"),
                        record.get("Street"),
                        record.get("City"),
                        record.get("State"),
                        record.get("LocationID"),
                        record.get("Reason"),
                        record.get("SectionViolations"),
                        record.get("RiskLevel"),
