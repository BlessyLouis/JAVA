//Lab-02: Implementing the concept of method and constructor overloading


//importing Scanner package for input operation
import java.util.Scanner;

//creation of main class
public class InventoryItem {
    private String itemName;
    private double price;
    private int quantity;

    // Constructors overloading
    //creation of constructors
    public InventoryItem() {
        this.itemName = "N/A";
        this.price = 0.0;
        this.quantity = 0;
    }

    public InventoryItem(String itemName, double price) {
        this.itemName = itemName;
        this.price = price;
        this.quantity = 0;
    }

    public InventoryItem(String itemName, double price, int quantity) {
        this.itemName = itemName;
        this.price = price;
        this.quantity = quantity;
    }


    //creation of member functions
    public void restock(int quantity) {
        this.quantity += quantity;
        System.out.println("Restocked " + quantity + " units of " + itemName + ".");
    }

    public void sell(int quantity) {
        if (this.quantity >= quantity) {
            this.quantity -= quantity;
            double revenue = quantity * price;
            System.out.println("Sold " + quantity + " units of " + itemName + " for Rs." + revenue + ".");
        } else {
            System.out.println("Not enough stock available to sell " + quantity + " units of " + itemName + ".");
        }
    }

   
    public double calculateRevenue() {
        return price * quantity;
    }

    // Method overloading to calculate revenue with a discount percentage
    public double calculateRevenue(int soldQuantity, double discountPercentage) {
        double discountedPrice = price - (price * (discountPercentage / 100.0));
        return soldQuantity * discountedPrice;
    }

    // Method overloading to calculate revenue with both discount and tax applied
    public double calculateRevenue(int soldQuantity, double discountPercentage, double taxPercentage) {
        double discountedPrice = price - (price * (discountPercentage / 100.0));
        double totalAfterTax = discountedPrice + (discountedPrice * (taxPercentage / 100.0));
        return soldQuantity * totalAfterTax;
    }

    // Method overloading to adjust the price of an item
    public void adjustPrice(double newPrice) {
        System.out.println("Adjusting price of " + itemName + " from Rs." + price + " to Rs." + newPrice + ".");
        price = newPrice;
    }

    // Method overloading to adjust the price of an item based on percentage change
    public void adjustPrice(double percentageChange, boolean increase) {
        if (increase) {
            double increaseAmount = price * (percentageChange / 100.0);
            price += increaseAmount;
            System.out.println("Increasing price of " + itemName + " by " + percentageChange + "% to Rs." + price + ".");
        } else {
            double decreaseAmount = price * (percentageChange / 100.0);
            price -= decreaseAmount;
            System.out.println("Decreasing price of " + itemName + " by " + percentageChange + "% to Rs." + price + ".");
        }
    }

    // Main method of the class
    public static void main(String[] args) {
        // creation of object for the package Scanner
        Scanner scanner = new Scanner(System.in);
	//take inputs
        System.out.println("Enter the item name:");
        String itemName = scanner.nextLine();

        System.out.println("Enter the item price:");
        double price = scanner.nextDouble();

        System.out.println("Enter the initial quantity:");
        int quantity = scanner.nextInt();
        // object creation for class
        InventoryItem item = new InventoryItem(itemName, price, quantity);

        
        System.out.println("Enter the quantity to restock:");
        int restockQuantity = scanner.nextInt();
	//calling member functions using objects
        item.restock(restockQuantity);

        System.out.println("Enter the quantity to sell:");
        int sellQuantity = scanner.nextInt();
        item.sell(sellQuantity);

        double totalRevenue = item.calculateRevenue();
        System.out.println("Total revenue from remaining inventory: Rs." + totalRevenue);

        System.out.println("Enter the discount percentage:");
        double discountPercentage = scanner.nextDouble();
        System.out.println("Total revenue after discount: Rs." + item.calculateRevenue(sellQuantity, discountPercentage));

        System.out.println("Enter the tax percentage:");
        double taxPercentage = scanner.nextDouble();
        System.out.println("Total revenue after discount and tax: Rs." + item.calculateRevenue(sellQuantity, discountPercentage, taxPercentage));

        System.out.println("Enter the new price:");
        double newPrice = scanner.nextDouble();
        item.adjustPrice(newPrice);

        System.out.println("Enter the percentage change for price adjustment:");
        double percentageChange = scanner.nextDouble();
        System.out.println("Do you want to increase or decrease the price? (Enter 'true' for increase, 'false' for decrease)");
        boolean increase = scanner.nextBoolean();
        item.adjustPrice(percentageChange, increase);
    }
}
