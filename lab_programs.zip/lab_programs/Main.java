//CIA-1:C2
//Write Java program that demonstrates all the OOPs such as Class, object, encapsulation, polymorphism, and data abstraction.

import java.util.Scanner;

// Main.java
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a restaurant
        MenuItem[] menuItems = createMenu(scanner);
        Restaurant restaurant = new Restaurant("Tasty Treats", menuItems);

        // Create a regular order
        MenuItem[] regularItems = createOrder(scanner, menuItems);
        Order regularOrder = new Order(restaurant, regularItems);
        regularOrder.displayOrder();

        // Create a special order with discount
        System.out.print("Enter discount percentage for special order: ");
        double discount = scanner.nextDouble();
        MenuItem[] specialItems = createOrder(scanner, menuItems);
        SpecialOrder specialOrder = new SpecialOrder(restaurant, specialItems, discount);
        specialOrder.displayOrder();

        scanner.close();
    }

    public static MenuItem[] createMenu(Scanner scanner) {
        System.out.print("Enter number of menu items: ");
        int numItems = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        MenuItem[] menuItems = new MenuItem[numItems];
        for (int i = 0; i < numItems; i++) {
            System.out.println("Enter details for menu item " + (i + 1));
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("Price: ");
            double price = scanner.nextDouble();
            scanner.nextLine(); // Consume newline character
            System.out.print("Category: ");
            String category = scanner.nextLine();

            menuItems[i] = new MenuItem(name, price, category);
        }
        return menuItems;
    }

    public static MenuItem[] createOrder(Scanner scanner, MenuItem[] menuItems) {
        System.out.print("Enter number of items in order: ");
        int numItems = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        MenuItem[] orderItems = new MenuItem[numItems];
        for (int i = 0; i < numItems; i++) {
            System.out.println("Enter details for item " + (i + 1));
            System.out.print("Name: ");
            String name = scanner.nextLine();

            // Find the MenuItem object from the menu
            MenuItem item = null;
            for (MenuItem menuItem : menuItems) {
                if (menuItem.getName().equalsIgnoreCase(name)) {
                    item = menuItem;
                    break;
                }
            }
            if (item == null) {
                System.out.println("Menu item not found.");
                return null;
            }

            orderItems[i] = item;
        }
        return orderItems;
    }
}
// MenuItem.java
class MenuItem {
    private String name;
    private double price;
    private String category;

    public MenuItem(String name, double price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }
}

// Restaurant.java
class Restaurant {
    private String name;
    private MenuItem[] menu;

    public Restaurant(String name, MenuItem[] menu) {
        this.name = name;
        this.menu = menu;
    }

    public String getName() {
        return name;
    }

    public MenuItem[] getMenu() {
        return menu;
    }
}

// Order.java
class Order {
    private Restaurant restaurant;
    private MenuItem[] items;

    public Order(Restaurant restaurant, MenuItem[] items) {
        this.restaurant = restaurant;
        this.items = items;
    }

    public double getTotal() {
        double total = 0;
        for (MenuItem item : items) {
            total += item.getPrice();
        }
        return total;
    }

    public void displayOrder() {
        System.out.println("Order from: " + restaurant.getName());
        System.out.println("Items:");
        for (MenuItem item : items) {
            System.out.println("- " + item.getName() + " $" + item.getPrice());
        }
        System.out.println("Total: $" + getTotal());
    }
}

// SpecialOrder.java
class SpecialOrder extends Order {
    private double discount;

    public SpecialOrder(Restaurant restaurant, MenuItem[] items, double discount) {
        super(restaurant, items);
        this.discount = discount;
    }

    @Override
    public double getTotal() {
        double total = super.getTotal();
        return total * (1 - discount / 100);
    }
}


