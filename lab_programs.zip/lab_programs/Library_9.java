//LAB-09: Implement collection Interfaces
import java.util.*;

public class Library_9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Library library = new Library();

        // Take user input for the number of books to be inserted
        System.out.print("Enter the number of books to be inserted: ");
        int numBooks = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        // Take user input for adding books
        System.out.println("Enter book details (ID, Title, Author):");
        for (int i = 0; i < numBooks; i++) {
            System.out.print("Book ID: ");
            int bookId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Title: ");
            String title = scanner.nextLine();
            System.out.print("Author: ");
            String author = scanner.nextLine();
            library.addBook(new Book(bookId, title, author));
        }

        // Take user input for the number of patrons to be inserted
        System.out.print("Enter the number of patrons to be inserted: ");
        int numPatrons = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        // Take user input for adding patrons
        System.out.println("Enter patron details (ID, Name):");
        for (int i = 0; i < numPatrons; i++) {
            System.out.print("Patron ID: ");
            int patronId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Name: ");
            String name = scanner.nextLine();
            library.addPatron(new Patron(patronId, name));
        }
        // Display all books and patrons in the library
        library.displayBooks();
        library.displayPatrons();

        // Perform remove and update operations
        System.out.println("Performing remove and update operations:");

        // Remove a book
        System.out.print("Enter the ID of the book to remove: ");
        int removeBookId = scanner.nextInt();
        library.removeBook(removeBookId);

        // Update a book
        System.out.print("Enter the ID of the book to update: ");
        int updateBookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter the new title: ");
        String newTitle = scanner.nextLine();
        System.out.print("Enter the new author: ");
        String newAuthor = scanner.nextLine();
        library.updateBook(updateBookId, newTitle, newAuthor);

        // Remove a patron
        System.out.print("Enter the ID of the patron to remove: ");
        int removePatronId = scanner.nextInt();
        library.removePatron(removePatronId);

        // Update a patron
        System.out.print("Enter the ID of the patron to update: ");
        int updatePatronId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter the new name: ");
        String newName = scanner.nextLine();
        library.updatePatron(updatePatronId, newName);

        // Display all books and patrons after modifications
        System.out.println("Books and patrons after modifications:");
        library.displayBooks();
        library.displayPatrons();

       
    }
}


// Define Book class
class Book {
    private String title;
    private String author;
    private int id;

    public Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
}

// Define Patron class
class Patron {
    private String name;
    private int id;

    public Patron(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

// Library class that manages books and patrons
class Library {
    private List<Book> books; // List of books
    private Queue<Patron> patrons; // Queue of patrons

    public Library() {
        books = new ArrayList<>();
        patrons = new LinkedList<>();
    }

    // Method to add a book to the library
    public void addBook(Book book) {
        books.add(book);
    }

    // Method to remove a book from the library
    public void removeBook(int bookId) {
        for (Iterator<Book> iterator = books.iterator(); iterator.hasNext();) {
            Book book = iterator.next();
            if (book.getId() == bookId) {
                iterator.remove();
                break;
            }
        }
    }

    // Method to update book details
    public void updateBook(int bookId, String newTitle, String newAuthor) {
        for (Book book : books) {
            if (book.getId() == bookId) {
                book.setTitle(newTitle);
                book.setAuthor(newAuthor);
                break;
            }
        }
    }

    // Method to retrieve a book by ID
    public Book getBookById(int bookId) {
        for (Book book : books) {
            if (book.getId() == bookId) {
                return book;
            }
        }
        return null; // Book not found
    }

    // Method to add a patron to the library
    public void addPatron(Patron patron) {
        patrons.offer(patron);
    }

    // Method to remove a patron from the library
    public void removePatron(int patronId) {
        for (Iterator<Patron> iterator = patrons.iterator(); iterator.hasNext();) {
            Patron patron = iterator.next();
            if (patron.getId() == patronId) {
                iterator.remove();
                break;
            }
        }
    }

    // Method to update patron details
    public void updatePatron(int patronId, String newName) {
        for (Patron patron : patrons) {
            if (patron.getId() == patronId) {
                patron.setName(newName);
                break;
            }
        }
    }

    // Method to retrieve a patron by ID
    public Patron getPatronById(int patronId) {
        for (Patron patron : patrons) {
            if (patron.getId() == patronId) {
                return patron;
            }
        }
        return null; // Patron not found
    }

    // Method to display all books in the library
    public void displayBooks() {
        System.out.println("Books in the library:");
        for (Book book : books) {
            System.out.println("ID: " + book.getId() + ", Title: " + book.getTitle() + ", Author: " + book.getAuthor());
        }
    }

    // Method to display all patrons in the library
    public void displayPatrons() {
        System.out.println("Patrons in the library:");
        for (Patron patron : patrons) {
            System.out.println("ID: " + patron.getId() + ", Name: " + patron.getName());
        }
    }
}

