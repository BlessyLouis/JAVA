//importing the Scanner class fro the util package for input operation
import java.util.Scanner;
//creation of main class Bank_4
public class Bank_4 {
    public static void main(String[] args) {
//object cretion for Scanner class
        Scanner scanner = new Scanner(System.in);
//input from user

        System.out.println("Enter savings account number:");
        String savingsAccNumber = scanner.next();
        System.out.println("Enter initial balance for savings account:");
        double savingsInitialBalance = scanner.nextDouble();
//creating object for class SavingsAccount
        SavingsAccount savingsAcc = new SavingsAccount(savingsAccNumber, savingsInitialBalance);

        System.out.println("Enter current account number:");
        String currentAccNumber = scanner.next();
        System.out.println("Enter initial balance for current account:");
        double currentInitialBalance = scanner.nextDouble();
        CurrentAccount currentAcc = new CurrentAccount(currentAccNumber, currentInitialBalance);
//creating object for class CurrentAccount
        System.out.println("Enter amount to deposit into savings account:");
        double depositAmount = scanner.nextDouble();
        savingsAcc.deposit(depositAmount);
//calling the deposit method(deposit operation can be performed only in savingAccount
        System.out.println("Enter amount to withdraw from current account:");
        double withdrawAmount = scanner.nextDouble();
        currentAcc.withdraw(withdrawAmount);
//calling the withdraw method(withdraw can be performed only in  current Account)
       
    }
}
// Abstract class for BankAccount
abstract class BankAccount {
    protected String accountNumber;
    protected double balance;
//constructor
    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited " + amount + ". New balance: " + balance);
    }

    public abstract void withdraw(double amount);

    // Abstract method for calculating interest
    public abstract void calculateInterest();
}

// SavingsAccount inherits from BankAccount
class SavingsAccount extends BankAccount {
    private static final double INTEREST_RATE = 0.05;

    public SavingsAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    public void withdraw(double amount) {
        System.out.println("Withdrawal not allowed from savings account");
    }

    public void calculateInterest() {
        double interest = balance * INTEREST_RATE;
        deposit(interest);
        System.out.println("Interest calculated: " + interest);
    }
}
// Hierarchical inheritance 
// CurrentAccount inherits from BankAccount
class CurrentAccount extends BankAccount {
// implementation of final keyword
    private static final double OVERDRAFT_LIMIT = 1000;

    public CurrentAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    public void withdraw(double amount) {
        if (balance + OVERDRAFT_LIMIT >= amount) {
            balance -= amount;
            System.out.println("Withdrew " + amount + ". New balance: " + balance);
        } else {
            System.out.println("Exceeded overdraft limit");
        }
    }

    public void calculateInterest() {
        System.out.println("No interest for current account");
    }
}

// Final class AccountHolder, cannot be subclassed
final class AccountHolder {
    private String name;
    private String address;

    public AccountHolder(String name, String address) {
        this.name = name;
        this.address = address;
    }
}


