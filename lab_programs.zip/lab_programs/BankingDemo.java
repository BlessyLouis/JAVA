//importing the Scanner class fro the util package for input operation
import java.util.Scanner;
//Encapsulation
public class BankingDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to JAVA Bank");

        // User input for amount
        System.out.print("Enter the amount: ");
        double amount = scanner.nextDouble();

        // User input for Fixed Deposit details
        System.out.println("Enter Fixed Deposit details:");
        System.out.print("Duration (in months): ");
        int duration = scanner.nextInt();
        System.out.print("Interest Rate (%): ");
        double fdInterestRate = scanner.nextDouble();

        // User input for Loan details
        System.out.println("Enter Loan details:");
        System.out.print("Interest Rate (%): ");
        double loanInterestRate = scanner.nextDouble();

        // User input for Insurance details
        System.out.println("Enter Insurance details:");
        System.out.print("Interest Rate (%): ");
        double insuranceInterestRate = scanner.nextDouble();

        // User input for Savings Account details
        System.out.println("Enter Savings Account details:");
        System.out.print("Interest Rate (%): ");
        double savingsInterestRate = scanner.nextDouble();
        System.out.print("Period (in years): ");
        int period = scanner.nextInt();

        // Creating Fixed Deposit
        FixedDeposit fd = new FixedDeposit("Fixed Deposit", fdInterestRate, duration);

        // Creating Loan
        Loan loan = new Loan("Home Loan", loanInterestRate);

        // Creating Insurance
        Insurance insurance = new Insurance("Life Insurance", insuranceInterestRate);

        // Creating Savings Account
        SavingsAccount savingsAccount = new SavingsAccount("Savings Account", savingsInterestRate, period);

        // Displaying options
        System.out.println("Select the product:");
        System.out.println("1. Fixed Deposit");
        System.out.println("2. Loan");
        System.out.println("3. Insurance");
        System.out.println("4. Savings Account");

        // User input for product selection
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        // Calculating interest based on the selected product
        double interest = 0;
        switch (choice) {
            case 1:
                interest = fd.calculateInterest(amount);
                break;
            case 2:
                interest = loan.calculateInterest(amount);
                break;
            case 3:
                interest = insurance.calculateInterest(amount);
                break;
            case 4:
                interest = savingsAccount.calculateInterest(amount);
                break;
            default:
                System.out.println("Invalid choice");
                break;
        }

        // Displaying interest
        System.out.println("Interest earned: Rs." + interest);
    }
}

//Data Abstraction
// Abstract class for Bank Products
abstract class BankProduct {
    protected String productName;
    protected double interestRate;

    public BankProduct(String productName, double interestRate) {
        this.productName = productName;
        this.interestRate = interestRate;
    }

    // Abstract method for calculating interest
    public abstract double calculateInterest(double amount);
}
//Inheritance-Heirachical inheritance
// Class representing Fixed Deposit
class FixedDeposit extends BankProduct {
    private int duration; // in months

    public FixedDeposit(String productName, double interestRate, int duration) {
        super(productName, interestRate);
        this.duration = duration;
    }

    // Method overriding
    @Override
    public double calculateInterest(double amount) {
        return (amount * interestRate * duration) / 12 / 100;
    }
}

// Class representing Loan
class Loan extends BankProduct {
    public Loan(String productName, double interestRate) {
        super(productName, interestRate);
    }

    // Method overriding
    @Override
    public double calculateInterest(double amount) {
        return (amount * interestRate) / 100;
    }
}

// Class representing Insurance
class Insurance extends BankProduct {
    public Insurance(String productName, double interestRate) {
        super(productName, interestRate);
    }

    // Method overriding
    @Override
    public double calculateInterest(double amount) {
        // Insurance usually doesn't give interest, so returning 0
        return 0;
    }
}

// Class representing Savings Account
class SavingsAccount extends BankProduct {
    private int period; // in years

    // Constructor with default period set to 1 year
    public SavingsAccount(String productName, double interestRate) {
        super(productName, interestRate);
        this.period = 1; // Default period set to 1 year
    }

    // Constructor with specified period
    public SavingsAccount(String productName, double interestRate, int period) {
        super(productName, interestRate);
        this.period = period;
    }

    // Method overloading
    public double calculateInterest(double amount) {
        return (amount * interestRate * this.period) / 100;
    }

    // Method overloading
    public double calculateInterest(double amount, int customPeriod) {
        return (amount * interestRate * customPeriod) / 100;
    }
}
