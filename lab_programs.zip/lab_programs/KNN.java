import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KNN {
    public static void main(String[] args) {
        // Load data from CSV
        List<Map<String, String>> data = loadDataFromCSV("C:/Users/Admin/Downloads/Data_Train.csv");

        // Add new column for Inspection_Results
        addInspectionResultsColumn(data);

        // Split data into training and testing sets (80-20)
        List<Map<String, String>> trainingSet = new ArrayList<>();
        List<Map<String, String>> testingSet = new ArrayList<>();
        splitData(data, trainingSet, testingSet, 0.8);

        // Train the KNN model
        int k = 5; // Specify the value of k
        KNNClassifier knnClassifier = new KNNClassifier(trainingSet, k);

        // Test the KNN model
        evaluateModel(knnClassifier, testingSet);
    }

    private static void addInspectionResultsColumn(List<Map<String, String>> data) {
        for (Map<String, String> row : data) {
            String reason = row.get("Reason");
            String inspectionResult = mapReasonToInspectionResult(reason);
            row.put("Inspection_Results", inspectionResult);
        }
    }

    private static String mapReasonToInspectionResult(String reason) {
        switch (reason) {
            case "FACILITY CHANGED":
                return "0";
            case "FAIL":
                return "1";
            case "FURTHER INSPECTION REQUIRED":
                return "2";
            case "INSPECTION OVERRULED":
                return "3";
            case "PASS":
                return "4";
            case "PASS(CONDITIONAL)":
                return "5";
            case "SHUT-DOWN":
                return "6";
            default:
                return "Unknown";
        }
    }

    private static List<Map<String, String>> loadDataFromCSV(String filename) {
        List<Map<String, String>> data = new ArrayList<>();
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String[] headers = br.readLine().split(",");
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                Map<String, String> row = new HashMap<>();
                for (int i = 0; i < headers.length; i++) {
                    if (i < values.length) {
                        row.put(headers[i], values[i]);
                    } else {
                        row.put(headers[i], ""); // Handle missing values
                    }
                }
                data.add(row);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    private static void splitData(List<Map<String, String>> data, List<Map<String, String>> trainingSet,
                                   List<Map<String, String>> testingSet, double ratio) {
        Collections.shuffle(data);
        int splitIndex = (int) (ratio * data.size());
        trainingSet.addAll(data.subList(0, splitIndex));
        testingSet.addAll(data.subList(splitIndex, data.size()));
    }

    private static void evaluateModel(KNNClassifier classifier, List<Map<String, String>> testingSet) {
        int truePositives = 0;
        int falsePositives = 0;
        int trueNegatives = 0;
        int falseNegatives = 0;

        for (Map<String, String> instance : testingSet) {
            String predicted = classifier.classify(instance);
            String actual = instance.get("Inspection_Results");
            if (predicted.equals("1") && actual.equals("1")) {
                truePositives++;
            } else if (predicted.equals("1") && !actual.equals("1")) {
                falsePositives++;
            } else if (!predicted.equals("1") && actual.equals("1")) {
                falseNegatives++;
            } else {
                trueNegatives++;
            }
        }

        double precision = calculatePrecision(truePositives, falsePositives);
        double recall = calculateRecall(truePositives, falseNegatives);
        double accuracy = calculateAccuracy(truePositives, trueNegatives, falsePositives, falseNegatives);
        double f1Score = calculateF1Score(precision, recall);

        System.out.println("Precision: " + precision);
        System.out.println("Recall: " + recall);
        System.out.println("Accuracy: " + accuracy);
        System.out.println("F1 Score: " + f1Score);
    }

    private static double calculatePrecision(int truePositives, int falsePositives) {
        if (truePositives + falsePositives == 0) {
            return 0.0;
        }
        return (double) truePositives / (truePositives + falsePositives);
    }

    private static double calculateRecall(int truePositives, int falseNegatives) {
        if (truePositives + falseNegatives == 0) {
            return 0.0;
        }
        return (double) truePositives / (truePositives + falseNegatives);
    }

    private static double calculateAccuracy(int truePositives, int trueNegatives, int falsePositives, int falseNegatives) {
        int total = truePositives + trueNegatives + falsePositives + falseNegatives;
        if (total == 0) {
            return 0.0;
        }
        return (double) (truePositives + trueNegatives) / total;
    }

    private static double calculateF1Score(double precision, double recall) {
        if (precision + recall == 0) {
            return 0.0;
        }
        return 2 * (precision * recall) / (precision + recall);
    }
}

class KNNClassifier {
    private List<Map<String, String>> trainingSet;
    private int k;

    public KNNClassifier(List<Map<String, String>> trainingSet, int k) {
        this.trainingSet = trainingSet;
        this.k = k;
    }

    public String classify(Map<String, String> instance) {
        List<Neighbor> neighbors = new ArrayList<>();
        for (Map<String, String> trainingInstance : trainingSet) {
            double distance = calculateDistance(instance, trainingInstance);
            neighbors.add(new Neighbor(trainingInstance.get("Inspection_Results"), distance));
        }
        Collections.sort(neighbors);
        Map<String, Integer> votes = new HashMap<>();
        for (int i = 0; i < k; i++) {
            Neighbor neighbor = neighbors.get(i);
            String label = neighbor.label;
            votes.put(label, votes.getOrDefault(label, 0) + 1);
        }
        return majorityVote(votes);
    }

    private double calculateDistance(Map<String, String> instance1, Map<String, String> instance2) {
        String inspectionResult1 = instance1.get("Inspection_Results");
        String inspectionResult2 = instance2.get("Inspection_Results");

        // Skip instances where the value is "Unknown"
        if (inspectionResult1.equals("Unknown") || inspectionResult2.equals("Unknown")) {
            return Double.POSITIVE_INFINITY; // Return a large value indicating infinity distance
        }

        int inspectionResults1 = Integer.parseInt(inspectionResult1);
        int inspectionResults2 = Integer.parseInt(inspectionResult2);
        return Math.abs(inspectionResults1 - inspectionResults2);
    }

    private String majorityVote(Map<String, Integer> votes) {
        return Collections.max(votes.entrySet(), Map.Entry.comparingByValue()).getKey();
    }

    static class Neighbor implements Comparable<Neighbor> {
        String label;
        double distance;

        public Neighbor(String label, double distance) {.
            this.label = label;
            this.distance = distance;
        }

        @Override
        public int compareTo(Neighbor other) {
            return Double.compare(this.distance, other.distance);
        }
    }
}
