package banking.loans;
// Interface for Loan
public interface Loaninterface {
    void applyForLoan(double amount); // Method to apply for a loan
    void repayLoan(double amount);    // Method to repay the loan
}

