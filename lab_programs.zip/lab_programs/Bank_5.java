//main class 
import java.util.Scanner;
import banking.loans.PersonalLoan;
import banking.loans.BusinessLoan;
import banking.loans.Loaninterface;
public class Bank_5{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking inputs for personal loan
        System.out.println("Enter the amount for personal loan:");
        double personalLoanAmount = scanner.nextDouble();
        Loaninterface personalLoan = new PersonalLoan(personalLoanAmount);

        System.out.println("Enter the additional amount to apply for personal loan:");
        double additionalAmount = scanner.nextDouble();
        personalLoan.applyForLoan(additionalAmount);

        System.out.println("Enter the amount to repay personal loan:");
        double personalRepaymentAmount = scanner.nextDouble();
        personalLoan.repayLoan(personalRepaymentAmount);

        // Taking inputs for business loan
        System.out.println("Enter the amount for business loan:");
        double businessLoanAmount = scanner.nextDouble();
        Loaninterface businessLoan = new BusinessLoan(businessLoanAmount);

        System.out.println("Enter the additional amount to apply for business loan:");
        additionalAmount = scanner.nextDouble();
        businessLoan.applyForLoan(additionalAmount);

        System.out.println("Enter the amount to repay business loan:");
        double businessRepaymentAmount = scanner.nextDouble();
        businessLoan.repayLoan(businessRepaymentAmount);

    }
}

