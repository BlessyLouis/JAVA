import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVOperation_11 {

    public static void main(String[] args) {
        String csvFile = "C:/Users/Admin/Downloads/tvmarketing.csv";
        String line;
        String cvsSplitBy = ",";

        // List to store data
        List<String[]> dataList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // Skip the header row
            br.readLine();

            // Read the CSV file line by line
            while ((line = br.readLine()) != null) {
                // Split the line by comma
                String[] data = line.split(cvsSplitBy);
                // Add the data to the list
                dataList.add(data);
            }

            // Print the data
            System.out.println("TV\tSales\tProfit/Loss");
            for (String[] data : dataList) {
                System.out.println(data[0] + "\t" + data[1] + "\t" + calculateProfitOrLoss(Double.parseDouble(data[1])));
            }

            // Perform basic operations
            double totalSales = 0;
            for (String[] data : dataList) {
                totalSales += Double.parseDouble(data[1]);
            }
            System.out.println("Total Sales: " + totalSales);

            // Calculate average sales
            double averageSales = totalSales / dataList.size();
            System.out.println("Average Sales: " + averageSales);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to calculate profit or loss
    public static String calculateProfitOrLoss(double sales) {
        // Define a condition for profit or loss, you can customize it based on your requirement
        if (sales > 10) {
            return "Profit";
        } else {
            return "Loss";
        }
    }
}
