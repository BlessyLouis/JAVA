public class WithoutThread{
public static void main(String[] args){
long start=System.nanoTime();
for(int i=1;i<=10000;i++){System.out.println("i= "+i);}
long end=System.nanoTime();
long elapsedTime=end-start;
System.out.println("Elapsed time for the task:"+elapsedTime+" nanosecond");
}
}