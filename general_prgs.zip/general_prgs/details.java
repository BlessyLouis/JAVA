//Method Overidding
class details{
public static void main(String[] agrs){
teacher t  = new teacher();
t.display();
}
}

class employee{
String name="Java";
public void display(){
System.out.println("this is  super class");
}
public employee(){
System.out.println("this is   contructor inside the super class");
}
}

class teacher extends employee{
String name="Blessy";
public void display(){
System.out.println(name);
System.out.println(super.name);
}
public teacher(){
//super();
System.out.println("this is   contructor inside the subclass");

}
}

