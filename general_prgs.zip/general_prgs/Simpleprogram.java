class simpleprogram
{
int num1,num2;
public static void main(String args[])
{
simpleprogram o1=new simpleprogram();
o1.num1=40;
o1.num2=35;
o1.add();
o1.sub();
o1.mul();
}
public void add()
{
int sum;
sum=num1+num2;
System.out.println("Sum ="+sum);
}
public void sub()
{
int diff;
diff=num1-num2;
System.out.println("Difference ="+diff);
}
public void mul()
{
int mul;
mul=num1*num2;
System.out.println("Product ="+mul);
}


}