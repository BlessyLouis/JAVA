import org.jfree.dtat.category.DefaultCategoryDataset;
public class BarChartExample{
    public static void main(String[] args){
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addvalue(50,"Category 1","Series 1");
        dataset.addvalue(60,"Category 1","Series 2");
        dataset.addvalue(40,"Category 2","Series 1");
        dataset.addvalue(70,"Category 2","Series 2");
    }

}