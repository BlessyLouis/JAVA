//Question:Implement a Java program to create a class representing a Bank with data members for bank name and location. Include member functions to add and remove branches, and display the list of branches

//solution:
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BankSystem {

    static class Branch {
        private String branchName;

        public Branch(String branchName) {
            this.branchName = branchName;
        }

        public String getBranchName() {
            return branchName;
        }
    }

    static class Bank {
        private String bankName;
        private String location;
        private List<Branch> branches;

        public Bank(String bankName, String location) {
            this.bankName = bankName;
            this.location = location;
            this.branches = new ArrayList<>();
        }

        public void addBranch(String branchName) {
            Branch branch = new Branch(branchName);
            branches.add(branch);
            System.out.println("Branch '" + branchName + "' added to the bank '" + bankName + "'.");
        }

        public void removeBranch(String branchName) {
            for (int i = 0; i < branches.size(); i++) {
                if (branches.get(i).getBranchName().equals(branchName)) {
                    branches.remove(i);
                    System.out.println("Branch '" + branchName + "' removed from the bank '" + bankName + "'.");
                    return;
                }
            }
            System.out.println("Branch '" + branchName + "' not found in the bank '" + bankName + "'.");
        }

        public void displayBranches() {
            System.out.println("Branches of Bank '" + bankName + "' located at '" + location + "':");
            if (branches.isEmpty()) {
                System.out.println("No branches found.");
                return;
            }
            for (Branch branch : branches) {
                System.out.println(branch.getBranchName());
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the name of the bank: ");
        String bankName = scanner.nextLine();

        System.out.print("Enter the location of the bank: ");
        String location = scanner.nextLine();

        Bank bank = new Bank(bankName, location);

        while (true) {
            System.out.println("\n1. Add Branch\n2. Remove Branch\n3. Display Branches\n4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter the name of the branch to add: ");
                    String addBranchName = scanner.nextLine();
                    bank.addBranch(addBranchName);
                    break;
                case 2:
                    System.out.print("Enter the name of the branch to remove: ");
                    String removeBranchName = scanner.nextLine();
                    bank.removeBranch(removeBranchName);
                    break;
                case 3:
                    bank.displayBranches();
                    break;
                case 4:
                    System.out.println("Exiting program...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
