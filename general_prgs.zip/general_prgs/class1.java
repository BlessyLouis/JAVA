package newpackage;
public class class1{
public void  display(){
System.out.println("this is from class1");
}
}