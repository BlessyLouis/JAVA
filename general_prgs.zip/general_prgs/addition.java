//Question:Create a Java program to demonstrate method overloading by defining multiple print() methods that can print different types of data such as integers, doubles, strings, and arrays.

//soln

import java.util.Scanner;
class Print{
int num;
double num2;
String greeting;

public void display( int num){
System.out.println(num+" This is a integer");
}
public void display( double num2){
System.out.println(num2+" This is a double");
}
public void display(String greeting){
System.out.println(greeting+" This is a String");
}

public static void main(String[]agrs){
Scanner s =new Scanner(System.in);
Print p=new Print();
System.out.println(" Enter any  integer");
int num=nextInt();
p.num=num;
p.display( int num);

System.out.println(" Enter any double ");
double num2=nextdouble();
p.num2=num2;
p.display( double num2);

System.out.println(" Enter any  String");
String greeting=nextLine();
p.greeting=greeting;
p.display(string greeting);


}


}