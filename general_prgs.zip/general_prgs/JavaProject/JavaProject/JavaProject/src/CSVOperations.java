import java.io.*;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CSVOperations {

    public static void main(String[] args) {
        String csvFile = "dataset.csv";
        String jsonFile = "dataset.json";
        String line;
        String cvsSplitBy = ",";

        // List to store data
        List<String[]> dataList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // Skip the header row
            br.readLine();

            // Read the CSV file line by line
            while ((line = br.readLine()) != null) {
                // Split the line by comma
                String[] data = line.split(cvsSplitBy);
                // Add the data to the list
                dataList.add(data);
            }

            // Print the data
            System.out.println("TV\tSales\tProfit/Loss");
            for (String[] data : dataList) {
                System.out.println(data[0] + "\t" + data[1] + "\t" + calculateProfitOrLoss(Double.parseDouble(data[1])));
            }

            // Perform basic operations
            double totalSales = 0;
            for (String[] data : dataList) {
                totalSales += Double.parseDouble(data[1]);
            }
            System.out.println("Total Sales: " + totalSales);

            // Calculate average sales
            double averageSales = totalSales / dataList.size();
            System.out.println("Average Sales: " + averageSales);

            // Write data to JSON file
            writeDataToJson(jsonFile, dataList);

            // Read data from JSON file
            List<String[]> jsonData = readDataFromJson(jsonFile);
            System.out.println("\nData read from JSON file:");
            for (String[] data : jsonData) {
                System.out.println(data[0] + "\t" + data[1]);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to calculate profit or loss
    public static String calculateProfitOrLoss(double sales) {
        // Define a condition for profit or loss, you can customize it based on your requirement
        if (sales > 1000) {
            return "Profit";
        } else {
            return "Loss";
        }
    }

    // Method to write data to JSON file
    public static void writeDataToJson(String jsonFile, List<String[]> dataList) {
        try (FileWriter fileWriter = new FileWriter(jsonFile)) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(fileWriter, dataList);
            System.out.println("\nData has been written to JSON file: " + jsonFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to read data from JSON file
    public static List<String[]> readDataFromJson(String jsonFile) {
        List<String[]> jsonData = new ArrayList<>();
        try (FileReader fileReader = new FileReader(jsonFile)) {
            ObjectMapper mapper = new ObjectMapper();
            jsonData = mapper.readValue(fileReader, List.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jsonData;
    }
}

