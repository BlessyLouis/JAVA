import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;

public class barcharteg {
    public static void main(String args[]) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset(); // Create a category
        dataset.addValue(50, "Category 1", "Series 1");
        dataset.addValue(60, "Category 1", "Series 2");
        dataset.addValue(40, "Category 2", "Series 1");
        dataset.addValue(70, "Category 2", "Series 2");

        // Create a bar chart
        JFreeChart chart = ChartFactory.createBarChart("Bar Chart Example", "Category", "Value", dataset);

        JFrame frame = new JFrame("Bar Chart Example"); // Corrected 'title:'
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ChartPanel chartPanel = new ChartPanel(chart);
        frame.getContentPane().add(chartPanel);
        frame.pack();
        frame.setVisible(true);
    }
}