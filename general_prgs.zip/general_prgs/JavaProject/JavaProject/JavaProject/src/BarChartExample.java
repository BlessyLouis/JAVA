import org.jfree.data.category.DefaultCategoryDataset;
public class BarChartExample {
    public static void main(String args[]){
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(50, "Category 1", "Series 1");
        dataset.addValue(60, "Category 1", "Series 2");
        dataset.addValue(40, "Category 2", "Series 1");
        dataset.addValue(70, "Category 2", "Series 2");
    }
}