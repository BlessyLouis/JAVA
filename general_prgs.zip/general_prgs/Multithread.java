class MultiThread{
public static void main(String[] args){
int n=8;
for (int i=1;i<n;i++){
MultithreadingDemo o=new MultithreadingDemo();
o.start();
}
}
}

class MultithreadingDemo extends Thread{
public void run(){
try{ 
System.out.println("Thread" + Thread.currentThread().getId() +" is running");

}
catch(Exception e){
System.out.println("Exception is caught");

}
}
}

