import java.util.Scanner;
class triangle{
int s1,s2,s3,b,h;
public void equilateral(){
if (s1==s2 && s2==s3){
System.out.println("This is an equilateral triangle");

}
else{
System.out.println("This is  not an equilateral triangle");
}
}

public void isosceles(){
if(s1==s2 || s2==s3){
System.out.println("This is  an isosceles triangle");

}
else{
System.out.println("This is  not an isosceles triangle");

}

}
public void scalene(){
if(s1!=s2 && s2!=s3){
System.out.println("This is scalene triangle");

}
else{
System.out.println("This is  not an scalene triangle");

}
}

public void area(){
area=1/2*(b*h);
System.out.println("The area of the traingle is :"+area);
}

public static void main(Sring[]args)
{
Scanner s= new Scanner(System.in);
traingle t=  new traingle();
System.out.println("Enter the  side 1:");
int s1=s.nextInt();
t.s1=s1;
System.out.println("Enter the  side 2:");
int s2=s.nextInt();
t.s2=s2;
System.out.println("Enter the  side 3:");
int s3=s.nextInt();
t.s3=s3;
System.out.println("Enter the  breadth:");
int b=s.nextInt();
t.b=b;
System.out.println("Enter the  height:");
int h=s.nextInt();
t.h=h;
t.area();
t.equilateral();
t.isosceles();
t.scalene();




}
}