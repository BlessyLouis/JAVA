// users/Users.java
package users;

public class users {
    public void adminFunctionality() {
        // Method for admin functionalities
        System.out.println("Admin functionalities implemented.");
    }

    public void customerFunctionality() {
        // Method for customer functionalities
        System.out.println("Customer functionalities implemented.");
    }
}
