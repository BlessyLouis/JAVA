
class Upcast{
public static void main(String[] args){
Animal a = new Animal("Fido", 3);
Dog d = new Dog("Buddy", 5, "Labrador");
System.out.println(a);  
System.out.println(d);
}
}
class Animal{
String name;
int age;
public Animal(String name, int age){
this.name=name;
this.age=age;
}
public String toString(){
return "Animal:" +name +" Age: "+age;
}

}
class Dog extends Animal{
String breed;
public Dog(String name,int age, String breed){
super(name,age);
this.breed=breed;
}
public String toString(){
return "Dog:" +super.toString()+ "Breed:" +breed;
}
}