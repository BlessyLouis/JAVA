class Student<T>{
T age;
Student(T age){
this.age=age;
}
}
public class GenRes1{
public static void main(String args[]){
Student<Float> std1= new Student<Float>(25.5f);
Student<String> std2= new Student<String>("25");
Studengt<int> std3= new Student<int>(25);
}
}