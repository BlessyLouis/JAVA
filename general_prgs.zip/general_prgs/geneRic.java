import java.util.Scanner;
class geneRic{
    public static <E> void display(E[]input){
        for(E element: input){
            System.out.println(element);

        }
        System.out.println();
    } 
    public static void main(String[] args) {
        Scanner s=new Scanner();
        <F> inpArray=[];
       
        display(inpArray);
        display(douArray);
    }
    public static <F> void input(){
        int n = System.out.println("Enter the number of elements in the array");
        s.nextInt
        for(i=0;i<=n;i++){
            <F> value = System.out.println("Enter the values");
            s.next<F>;
            inpArray.add(value);
        }
    }
}