package math;
public class Calculator{
int num1, num2;
public static int add( int num1, int num2){
int sum= num1+num2;
return sum;
}
public static int sub( int num1, int num2){
int diff= num1-num2;
return diff;
}
public static int mul( int num1, int num2){
int prod= num1*num2;
return prod;
}
public static int div( int num1, int num2){
int quotient= num1/num2;
return quotient;
}
}