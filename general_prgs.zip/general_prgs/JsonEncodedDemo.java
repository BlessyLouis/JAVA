import org.json.simple.JSONObject;
class JsonEncodedDemo{
    public static void main(String[] args){
        JSONObject obj = new JSONObject();
        obj.put("name","foo");
        obj.put("num",100);
        obj.put("Balance",1000.21);
        obj.put("is_vip","True");
        System.out.print(obj);

    }
}