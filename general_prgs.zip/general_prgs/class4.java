import newpackage.class3;
class class4{
public static void main(String[] args){
class3 c3=new class1();
c3.show();
}
}