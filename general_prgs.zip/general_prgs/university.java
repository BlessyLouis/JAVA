//create a class teacher  with data members and member fns  create a class university and members fns of class teacher

class university{
public  static void main(String args[])
{
teacher t =new teacher();
System.out.println(t.name+t.department+t.id);
t.mssg();
}
}
class teacher{
String name="Maria";
String department="Computer Science";
int id=101;
public  void mssg()
{
System.out.println("Display message");
}
}