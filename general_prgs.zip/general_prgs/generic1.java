class generic1{
static<T> void genericDisplay(T element){
//System.out.println(element.getClass().getName()+"="+element);
System.out.println(element);
}
public static void main(String[]args){
//calling generic method with integer argument
genericDisplay(11);
//calling generic method with string argument
genericDisplay("GeeksForGeeks");
//calling generic method with double argument
genericDisplay(1.0);
}
}