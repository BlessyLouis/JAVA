//question:Write a Java program to demonstrate method overloading by defining multiple calculate() methods that can perform addition, subtraction, multiplication, and division of integers and doubles.

//soln:

import java.util.Scanner;
class Cal{
int num1,num2;
double num3,num4;\

public void calculate(int num1,int num2){
int sum= num1+ num2;
int diff= num1-num2;
int product =num1*num2;
int q=num1/num2;
System.out.println("The Sum  of these integers is  :"+sum);
System.out.println("The difference  of these integers is  :"+diff);
System.out.println("The product of these integers is  :"+product);
System.out.println("The Quoiteient  of these integers is  :"+q);
}

public void calculate(double num3,double num4){
int sum= num3+ num4;
int diff= num3-num4;
int product =num3*num4;
int q=num3/num4;
System.out.println("The Sum  of these doubles is  :"+sum);
System.out.println("The difference  of these doubles is  :"+diff);
System.out.println("The product of these doubles is  :"+product);
System.out.println("The Quoiteient  of these doubles is  :"+q);
}




public static void main(String[]args)
{
Scanner s =new Scanner(System.in);
Cal c=new Cal();
System.out.println("Enter any integer: ");
int num1=s.nextInt();
c.num1=num1;
System.out.println("Enter any integer: ");
int num2=s.nextInt();
c.num2=num2;
c.calculate(num1,num2);
System.out.println("Enter any double: ");
double num3=s.nextDouble();
c.num3=num3;
System.out.println("Enter any double: ");
double num4=s.nextDouble();
c.num4=num4;
c.calculate(num3,num4);
}
}