public class WithThread{
public static void main(String[] args){
SampleThread threadObject=new SampleThread();
Thread thread = new Thread(threadObject);
System.out.println("Thread about to start");
long start=System.nanoTime();
thread.start();
long end=System.nanoTime();
long elapsedTime=end-start;
System.out.println("Elapsed time for the task:"+elapsedTime+" nanosecond");

}

}
class SampleThread implements Runnable{
public void run(){
System.out.println("Thread is running");
for(int i=1;i<=100;i++){System.out.println("i= "+i);}
thread.stop();
}
}