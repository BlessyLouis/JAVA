// products/Products.java
package products;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
public class Products {
    private List<Product> productList;

    public Products() {
        productList = new ArrayList<Product>();
        // Initialize productList with sample products
        productList.add("Laptop", 999.99, 10);
        productList.add("Smartphone", 699.99, 15);
        productList.add("Tablet", 299.99, 20);
        productList.add("Headphones", 99.99, 30);
        productList.add("Mouse", 19.99, 50);
    }


    public void displayProducts() {
        System.out.println("Available Products:");
        for (Products product : productList) {
            System.out.println(product.getName() + " - $" + product.getPrice() + " - Quantity: " + product.getQuantity());
        }
    }
}
