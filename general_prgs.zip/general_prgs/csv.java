import java.io.*;
import java.util.Scanner;
public class csv{
public static void main(String[] args) throws Exception{
//parsing a csv file into Scanner class constructor
Scanner sc = new Scanner(new File("C:\\Users\\Admin\\Downloads\\score.csv"));
sc.useDelimiter(",");//sets the delimiter pattern
while(sc.hasNext()){
// find  and return the next complete token from this scanner
System.out.print(sc.next()+" ");

}
sc.close();

}
}