class generic2{
public static<E> void printArray(E[]inputArray){
//Display array elements 
for(E element : inputArray){
System.out.printf("%s",element);
}
System.out.println();
}
public static void main(String args[]){
//Create arrays of integer, diuble and character
Integer[] integerArray={5,4,3,2,1};
Double[] doubleArray={1.21,22.12,13.32};
Character[] characterArray={'Y','O','U'};
System.out.println("integerArray contains");
printArray(integerArray);
System.out.println("doubleArray contains");
printArray(doubleArray);
System.out.println("characterArray contains");
printArray(characterArray);
}
}