//question:Write a Java program to showcase method overloading for a calculatePerimeter() method that can calculate the perimeter of a square, a rectangle, and a circle.

//soln:

import java.util.Scanner;

class Perimeter {
    int side,length, breadth;float radius;
    
    public void  calculatePerimeter( int side){
        int perimeter= 4*side;
	System.out.println("The perimeter of the square with side length "+side+" is "+ 	perimeter);
    }

     public void  calculatePerimeter(int length, int breadth){
         int perimeter= 2*(length + breadth);
	System.out.println("The perimeter of the rectangle with length "+length+" and breadth 	"+breadth+" is "+ 	perimeter);
    }
     public void  calculatePerimeter( float radius){
        double perimeter= 2*3.14*radius;
	System.out.println("The perimeter of the circle with radius "+radius+" is "+ 	perimeter);
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
       	Perimeter p = new Perimeter();

        System.out.println("Enter the side length of a square: ");
        int  side = s.nextInt();
        p.side=side;
	p.calculatePerimeter(side);
	
	System.out.println("Enter the  length of a rectangle: ");
        int  length = s.nextInt();
        p.length=length;
	System.out.println("Enter the  breadth of a rectangle: ");
        int breadth = s.nextInt();
        p.breadth=breadth;
	p.calculatePerimeter(length,breadth);
	
	System.out.println("Enter the radius of the circle ");
        float  radius = s.nextFloat();
        p.radius=radius;
	p.calculatePerimeter(radius);

        
    }
}

