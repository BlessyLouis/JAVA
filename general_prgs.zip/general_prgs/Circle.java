package geometry;
public class Circle{
double radius;
public static double area(double radius){
double area=3.14*radius*radius;
return area;
}
public  static double circumference(double radius){
double circum=2*3.14*radius;
return circum;
}
}