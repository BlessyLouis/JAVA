import newpackage.class1;
class class2{
public static void main(String[] args){
class1 c1=new class1();
c1.display();
}
}