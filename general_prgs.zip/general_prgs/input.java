//importing package for taking input
import java.util.Scanner;
class input{
public static void main(String args[]){
//Creating object for scanner class
Scanner obj =new Scanner(System.in);
System.out.println("Enter Name");
System.out.println("Enter phone number");
System.out.println("Enter salary");
System.out.println("Enter  percentage of hike");

//taking input
String name=obj.nextLine();
int  phoneno=obj.nextInt();
double sal=obj.nextDouble();
float hike=obj.nextFloat();

System.out.println("Name is"+name);
System.out.println("Phone number is"+phoneno);
System.out.println("salary is"+sal);
System.out.println("Hike is"+hike);



}
}