//class creation
class Adder{
// different metods with same name but different  number of parameters
static int add (int a, int b){return(a+b);
}
static double  add (int a ,int b){return(a+b);
}
static  float  add(int a, int b ){return(a+b);} 
public static void main(String args[]){
System.out.println(add(11,11));
System.out.println(add(11,11));
System.out.println(add(11,11));
}
}

