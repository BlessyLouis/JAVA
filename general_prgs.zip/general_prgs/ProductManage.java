package products;

import java.util.ArrayList;
import java.util.List;

public class ProductManager {

    public static List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();

        // Adding some sample products
        productList.add(new Product("Laptop", 999.99, 10));
        productList.add(new Product("Smartphone", 699.99, 15));
        productList.add(new Product("Tablet", 299.99, 20));
        productList.add(new Product("Headphones", 99.99, 30));
        productList.add(new Product("Mouse", 19.99, 50));

        return productList;
    }
}
