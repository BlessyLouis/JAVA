//question:Create a Java program to implement method overloading for a convert() method that can convert integers to strings, doubles to strings, and strings to integers.I.

//soln:

import java.util.Scanner;
class Conversion{
int num1;
double num2;
String s1

public String convert(int num1){
System.out.println("The original Data type of "+num1+" is  "+ getClass(num1));
new_str= String(num1)
System.out.println("The converted Data type of "+num1+" is  "+ getClass(new_str));

}
public String convert(double num2){
System.out.println("The original Data type of "+num2+" is  "+ getClass(num2));
new_str= String(num2)
System.out.println("The converted Data type of "+num1+" is  "+ getClass(new_str));
}

public int convert(String s1){
System.out.println("The original Data type of "+num1+" is  "+ getClass(s1));
new_int= int(s1)
System.out.println("The converted Data type of "+num1+" is  "+ getClass(new_int));
}



public static void main(String[]args)
{
Scanner s =new Scanner(System.in);
Conversion c=new Conversion();
System.out.println("Enter any integer: ");
int num1=s.nextInt();
c.num1=num1;
c.convert(num1);
System.out.println("Enter any double: ");
double num3=s.nextDouble();
c.num3=num3;
c.convert(num3);
System.out.println("Enter any string: ");
String s1= s.next();
c.s1=s1;
c.convert(s1);
}
}