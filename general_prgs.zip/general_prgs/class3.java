package newpackage;
class class3{

public void show(){
System.out.println("this is from class3")
}
public void add(int a, int b){
int c ;
c=a+b;
System.out.println("Result= "+c);
}
}