//question:Implement a Java program to demonstrate method overloading by defining multiple displayInfo() methods for displaying information about a person, a book, and a car.

//soln:

import java.util.Scanner;

class display {
    int age,ISBN, publication_year, year;
    long phone_no;
    String name, qualification, author, title,make,, model ;

    public void displayinfo(String name, String qualification,int age, long phone_no) {
        System.out.println("Person Deatils:");
	System.out.println("__________________________________________________");
	System.out.println("Name: "+name);
	System.out.println("Age: "+age);
	System.out.println("Phone Number : "+phone_no);
	System.out.println("Qualification: "+qualification);

    }

    public void displayinfo(String title, String author,int ISBN, int publication_year) {
        System.out.println("Book Deatils:");
	System.out.println("__________________________________________________");
	System.out.println("Title: "+title);
	System.out.println("Author: "+author);
	System.out.println("ISBN : "+ISBN);
	System.out.println("Year of Publication: "+publication_year);

    }
   public void displayinfo(String make,String model, int year) {
        System.out.println("Car Deatils:");
	System.out.println("__________________________________________________");
	System.out.println("Make: "+make);
	System.out.println("Model: "+model);
	System.out.println("Year: "+year);

    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
     	display d = new display();

        System.out.println("Enter  the person name: ");
       	String name=s.next();
	d.name=name;
	
	System.out.println("Enter the age of the person: ");
	int age=s.nextInt();
	d.age=age
	
	System.out.println("Enter the phone number : ");
	long phone_no=s.nextLong();
	d.phone_no=phone_no;

	System.out.println("Enter the qualification of the person:");
	String qualification= s.next();
	d.qualification=qualification;
	d.displayinfo(name,qualification,age,phone_no);

        System.out.println("Enter  the Book Title: ");
       	String title=s.next();
	d.title=title;
	
	System.out.println("Enter the Author name: ");
	String author =s.next();
	d.author=author;
	
	System.out.println("Enter the ISBN : ");
	int ISBN=d.nextInt();
	d.ISBN=ISBN;

	System.out.println("Enter the year of publication:");
	int publication_year= s.nextInt();
	d.publication_year=publication_year;
	displayinfo(title,author,ISBN,publication_year);
	
	System.out.println("Enter  the Car make: ");
       	String make=s.next();
	d.make=make;
	
	System.out.println("Enter the car model: ");
	String model=s.next();
	d.model=model;
	
	System.out.println("Enter the year: ");
	int year=d.nextInt();
	d.year=year;
	d.displayinfo(make,model,year);





       
       
    }
}
