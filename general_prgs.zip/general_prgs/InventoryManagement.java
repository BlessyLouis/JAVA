//Lab-03:Implement the static keyword – static variable, static block, static function and static class


//code:
//importing Scanner package for input operation

import java.util.Scanner;

public class InventoryManagement {
    private static int totalItems = 0;
    private static double totalCost = 0;

    static {
        totalItems = 100; // Initial inventory size
    }

    public static void displayTotalItems() {
        System.out.println("Total items in inventory: " + totalItems);
    }

    public static void displayTotalCost() {
        System.out.println("Total cost of all items: $" + totalCost);
    }

    public static void updateTotalItems(int quantity) {
        totalItems += quantity;
    }

    public static void updateTotalCost(double cost) {
        totalCost += cost;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Display initial total items in inventory
        displayTotalItems();

        // Getting input from the user
        System.out.println("Enter the number of items to add to inventory: ");
        int numItems = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Add items to inventory
        for (int i = 0; i < numItems; i++) {
            System.out.println("Enter item name: ");
            String itemName = scanner.nextLine();
            System.out.println("Enter item quantity: ");
            int itemQuantity = scanner.nextInt();
            System.out.println("Enter item price: ");
            double itemPrice = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            // Update total items in inventory
            updateTotalItems(itemQuantity);

            // Calculate total cost for the item and update total cost in inventory
            double itemCost = itemQuantity * itemPrice;
            updateTotalCost(itemCost);
        }

        // Display total items and total cost in inventory
        displayTotalItems();
        displayTotalCost();

       
    }
}

