//Class Creation
class sample
{
//intialize variables that to be used in non-static methods
String name,course;
int reg_no;
//Main function
public static void main(String args[])
{
// to access any data members created outside the main fuction needs object , whereas the ones inside main fuction does not need objects
System.out.println("NAME: Blessy"+"\n"+ "Class: MDS B"+"\n"+"Regno: 234816");
//object creation
sample o1=new sample();
o1.name="Blessy";
o1.course="MDSB";
o1.reg_no=2348416;
o1.display();

}
//non static method
public void display()
{
// no need to use objects to call members inside non-static method
System.out.println("Name:"+name);
System.out.println("Course:"+course);
System.out.println("RegNO:"+reg_no);
}
 

}