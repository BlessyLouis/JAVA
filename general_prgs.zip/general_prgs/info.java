import java.util.Scanner;
class info{
public static void main(String[] args){
Scanner s = new Scanner(System.in);
Studentinfo myObj=new Studentinfo();
System.out.println("Enter the name");
String name =s.next();
//myObj.name=name;

myObj.studentName(name);
System.out.println("Enter the marks");
int marks =s.nextInt();
//myObj.marks=marks;
myObj.studentMarks();

}
}
interface Firstinterface{
public void  studentName(String name);
}
interface Secondinterface{
public void studentMarks(int Marks);
}

class Studentinfo implements Firstinterface,Secondinterface{
public void studentName( String name){
System.out.println(" Student name is : "+name);

}
public void studentMarks( int marks){
System.out.println("Marks scored is  "+marks);
}
}



