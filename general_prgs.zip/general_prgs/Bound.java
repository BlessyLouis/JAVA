import java.util.Scanner;
public class Bound{
public static void main(String[] args){
Scanner s = new Scanner(System.in);
System.out.println("Enter an integer:");
int intValue=s.nextInt();
System.out.println("Enter an double:");
double doubleValue=s.nextDouble();
System.out.println("Enter a string:");
String stringValue=s.next();
MyInterface<object> myInterface = new MyInterface<object>(){
public object performOperation(object value){
if (value instanceof Integer){return (int)value*2;}
elseif(value instanceof Double){return (double)value/2;}
elseif(value instanceOf String){return ((String)value).toUpperCase();}
else{return null;}
}
}
object r1= myInterface.performanceOperation(intValue);
object r2= myInterface.performanceOperation(doubleValue);
object r3= myInterface.performanceOperation(stringValue);
System.out.println("Result 1:"+r1);
System.out.println("Result 2:"+r2);
System.out.println("Result 3:"+r3);
}
}
interface MyInterface<T>{
T performOperation(T value):
}