public class access
{
//data members with private access modifers
private int num=30;
public static void main (String args[])
{
access o=new access();
System.out.println("The Number is:"+o.num);
person p = new person();
p.set("JAVA");
System.out.println("Name:"+p.get());
o.display();
}
//member fuctions with private access modifiers
private void display()
{
System.out.println("The number  is printed in the display method:"+num);
}
}

//encapsulation
class person{
private String name;
public  String get(){
return name;}
public void set(String name){
this.name=name;}
}