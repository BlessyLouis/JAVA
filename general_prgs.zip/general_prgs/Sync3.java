class geneRic{
    public static <E> void display(E[]input){
        for(E element: input){
            System.out.println(element);

        }
        System.out.println();
    } 
    public static void main(String[] args) {
        Integer[] intArray={5,4,3,2,1};
        Double[] douArray={1.21,3.45,12.45};
        display(intArray);
        display(douArray);
    }
}