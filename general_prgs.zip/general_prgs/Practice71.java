import math.Calculator;
import geometry.Circle;
class Practice71{

public static  void main (String[] args)
{
int num1=45;
int num2=78;
double radius=34.56;
System.out.println("The sum of  the given numbers is :"+Calculator.add(num1, num2));
System.out.println("The Difference of  the given numbers is :"+ Calculator.sub(num1,num2));
System.out.println("The product  of  the given numbers is :"+ Calculator.mul(num1, num2));
System.out.println("The Qoutient  of  the given numbers is :"+ Calculator.div(num1, num2));
System.out.println("The area  of  the given  radius  is :"+ Circle.area(radius));
System.out.println("The circumference  of  the given  radius  is :"+ Circle.circumference(radius));
}

}