package products;

import java.util.ArrayList;
import java.util.List;

public class ProductManager {
    private static List<Product> productList = new ArrayList<>();

    public static void main(String[] args) {
        // Populate productList
        productList.add(new Product("Laptop", 999.99, 10));
        productList.add(new Product("Smartphone", 699.99, 15));
        productList.add(new Product("Tablet", 299.99, 20));
        productList.add(new Product("Headphones", 99.99, 30));
        productList.add(new Product("Mouse", 19.99, 50));
    }

    public static List<Product> ListProducts() {
        return productList;
    }
}
