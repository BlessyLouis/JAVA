// shopping/ShoppingCart.java
package shopping;

import java.util.ArrayList;
import java.util.List;
import products.Product;

public class ShoppingCart {
    private List<Product> cartItems;

    public ShoppingCart() {
        this.cartItems = new ArrayList<>();
    }

    public void addItem(Product product) {
        cartItems.add(product);
        System.out.println(product.getName() + " added to cart.");
    }

    public void removeItem(Product product) {
        if (cartItems.contains(product)) {
            cartItems.remove(product);
            System.out.println(product.getName() + " removed from cart.");
        } else {
            System.out.println("Item not found in cart.");
        }
    }

    public double getTotalBill() {
        double total = 0;
        for (Product item : cartItems) {
            total += item.getPrice();
        }
        return total;
    }
}
