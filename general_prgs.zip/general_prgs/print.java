//Question:Create a Java program to demonstrate method overloading by defining multiple print() methods that can print different types of data such as integers, doubles, strings, and arrays.

//soln

import java.util.Scanner;
class Print{
int num;
double num2;
String greeting;

public void display( int num){
System.out.println(num+"  is a integer");
}
public void display( double num2){
System.out.println(num2+"  is a double");
}
public void display(String greeting){
System.out.println(greeting+"  is a String");
}

public static void main(String[]agrs){
Scanner s =new Scanner(System.in);
Print p=new Print();
System.out.println(" Enter any  integer");
int num=s.nextInt();
p.num=num;
p.display(num);

System.out.println("Enter any  String: ");
String greeting=s.next();
p.greeting=greeting;
p.display(greeting);


System.out.println(" Enter any double ");
double num2=s.nextDouble();
p.num2=num2;
p.display(num2);




}


}