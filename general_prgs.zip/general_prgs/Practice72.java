import java.util.List;
import java.util.Scanner;
import products;
import products.Products;
import shopping.ShoppingCart;
import users.Users;

public class Practice72 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Products products = new Products();
        List<Product> productList = products.listProducts();

        System.out.println("Available Products:");
        for (Product product : productList) {
            System.out.println(product.getName() + " - $" + product.getPrice());
        }

        ShoppingCart cart = new ShoppingCart();

        // Ask user to select products to add to the cart
        while (true) {
            System.out.println("Enter the name of the product to add to cart (or type 'done' to finish):");
            String productName = scanner.nextLine();
            if (productName.equalsIgnoreCase("done")) {
                break;
            }
            Product selectedProduct = getProductByName(productList, productName);
            if (selectedProduct != null) {
                cart.addItem(selectedProduct);
            } else {
                System.out.println("Product not found.");
            }
        }

        // Ask user if they want to remove items from the cart
        while (true) {
            System.out.println("Do you want to remove an item from the cart? (yes/no)");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("yes")) {
                System.out.println("Enter the name of the product to remove from cart:");
                String productName = scanner.nextLine();
                Product selectedProduct = getProductByName(cart.getCartItems(), productName);
                if (selectedProduct != null) {
                    cart.removeItem(selectedProduct);
                    System.out.println("Item removed from cart.");
                } else {
                    System.out.println("Product not found in cart.");
                }
            } else if (choice.equalsIgnoreCase("no")) {
                break;
            } else {
                System.out.println("Invalid choice. Please enter 'yes' or 'no'.");
            }
        }

        // Calculate and print total bill
        double totalBill = cart.getTotalBill();
        System.out.println("Total Bill: $" + totalBill);

        scanner.close();

        // Simulate admin and customer functionalities
        Users users = new Users();
        users.adminFunctionality();
        users.customerFunctionality();
    }

    // Method to get product by name
    private static Product getProductByName(List<Product> productList, String name) {
        for (Product product : productList) {
            if (product.getName().equalsIgnoreCase(name)) {
                return product;
            }
        }
        return null;
    }
}
