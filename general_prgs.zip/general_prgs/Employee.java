//Question:Create a Java program to model a basic library system. Define a class Book with data members representing book title, author, and ISBN. Include member functions to check out and return books, along with displaying book details

//Solution

class Book{
String title,author;
int isbn;

public void display(){
System.out.println("Books Avaiable:")
System.out.println("Book Title:"+title);
System.out.println("Book Author:"+author);
System.out.println("Book ISBN:"+isbn);
}

public void checkout(){
System.out.println("The Book with ISBN :"+isbn+"is check out and not avaiable currently");
}
public void return(){
System.out.println("The Book with ISBN :"+isbn+"is returned successfully and is currently avaiable");
}
public static void main(String[]args)
{
Book b=new Book();
b.title="Harry Potter";
b.author="JK Rowling";
b.isbn=123;
b.display();
b.checkout();
b.return();
}
}